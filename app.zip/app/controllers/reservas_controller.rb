class ReservasController < ApplicationController
  require 'wired'
  require 'date'
  before_action :set_reserva, only: [:edit, :destroy]
  skip_before_filter  :verify_authenticity_token
  # GET /reservas
  # GET /reservas.json
  def index
    @reservas = Reserva.all
  end

  # GET /reservas/1
  # GET /reservas/1.json
  def show
    wired = Wired.new
    response_a = wired.aquire_token
    if response_a['status']=0
      # RECUPERA RESERVAS NUEVAS 
      ancillary= 1
      mark= 0
      response_a = wired.fetch_new_bookings(ancillary, mark)
    end
    
    respond_to do |format|
      if response_a['status']=0
        
        @response={'status' => response_a['status'],'response' => Array.new { Hash.new }}
        @i = -1
        response_a['response'].each { |e| 

          @reserva = Reserva.find_by(reservation_code: e['reservation_code'])
         
          if  @reserva == nil 
              if not e['status'] == 5

                asigna_response(e)

                @reserva = Reserva.new()

                @reserva.id_channel = e['id_channel']
                @reserva.special_offer = e['special_offer']
                @reserva.reservation_code = e['reservation_code']
                @reserva.arrival_hour = e['arrival_hour']
                @reserva.booked_rate = e['booked_rate']
                @reserva.customer_mail = e['customer_mail']
                @reserva.customer_country = e['customer_country']
                @reserva.children = e['children']
                @reserva.payment_gateway_fee = e['payment_gateway_fee']
                @reserva.customer_surname = e['customer_surname']
                @reserva.date_departure = e['date_departure']
                @reserva.forced_price = e['forced_price']
                @reserva.amount_reason = e['amount_reason']
                @reserva.customer_city = e['customer_city']
                @reserva.opportunities = e['opportunities']
                @reserva.date_received = e['date_received']
                @reserva.was_modified = e['was_modified']
                @reserva.sessionSeed = e['sessionSeed']
                @reserva.customer_name = e['customer_name']
                @reserva.date_arrival = e['date_arrival']
                @reserva.status = e['status']
                @reserva.channel_reservation_code = e['channel_reservation_code']
                @reserva.customer_phone = e['customer_phone']
                @reserva.orig_amount = e['orig_amount']
                @reserva.men = e['men']
                @reserva.customer_notes = e['customer_notes']
                @reserva.customer_address = e['customer_address']
                @reserva.status_reason = e['status_reason']
                @reserva.roomnight = e['roomnight']
                @reserva.customer_language = e['customer_language']
                @reserva.fount = e['fount']
                @reserva.customer_zip = e['customer_zip']
                @reserva.amount = e['amount']
                @reserva.cc_info = e['cc_info']
                @reserva.room_opportunities = e['room_opportunities'] 
                @reserva.customer_language_iso = e['customer_language_iso']

                if @reserva.save
                    j = 0
                    err = 0
                    e['rooms_occupancies'].each { |f| 

                      @room = @reserva.rooms.new()
                      @room.id_room = f['id'] 
                      @room.occupancy = f['occupancy']
                      @room.status = 0
                      
                      if not @room.save
                          @response_err = {'status' => -2100, 'response' => "No se pudo salvar el Room de la reserva: #{e['reservation_code']}"}
                          err = 1
                      end
                      j = j + 1
                    }
                    if err == 0
                      @response['response'][@i]['id']=@reserva['id']
                    else
                      format.json { render :json => @response_err, notice: 'Error al grabar room.'}
                    end
                else
                    @response['response'][@i]['id']=0
                end
              end
          else
            if @reserva['status'] == 6
              if e['status'] != 5 
                @reserva['status'] = 1
                @reserva.save       

                asigna_response(e)

                @response['response'][@i]['id']=@reserva['id']
              end  
            else 
              asigna_response(e)

              @response['response'][@i]['id']=@reserva['id'] 
           
            end 
          end
     
        }
        format.json { render :json => @response, notice: 'Recuperacion de reservas exitosa.'}
      else
        format.json { render json: response_a, status: :unprocessable_entity }
      end
    end
  end
  def asigna_response(e)
    @i = @i + 1
    @response['response'] << {
                'id_channel' => e['id_channel'],
                'reservation_code' => e['reservation_code'],
                'arrival_hour'  => e['arrival_hour'],
                'customer_mail'  => e['customer_mail'],
                'customer_country'  => e['customer_country'],
                'customer_surname'  => e['customer_surname'],
                'rooms_occupancies'  => e['rooms_occupancies'],
                'date_departure'  => e['date_departure'],
                'customer_city'  => e['customer_city'],
                'customer_name'  => e['customer_name'],
                'date_arrival'  => e['date_arrival'],
                'customer_phone'   => e['customer_phone'],
                'customer_notes'  => e['customer_notes'],
                'customer_address'  => e['customer_address'],
                'amount'  => e['amount'],
                'status'  => e['status']}
  end 
  # GET /reservas/new
  def new
    @reserva = Reserva.new
  end

  # GET /reservas/1/edit
  def edit
  end

  # POST /reservas
  # POST /reservas.json
  def create
   
  end

  # PATCH/PUT /reservas/1
  # PATCH/PUT /reservas/1.json
  def update
    wired = Wired.new
    @response = wired.aquire_token
    respond_to do |format|
      if  @response['status']=0
          i = -1
          reservations = Array.new
          params['reservations'].each { |e|  
            if e['status'] == 0
              i = i + 1
              reservations[i] = e['reservation_code']
            else
              @reserva = Reserva.find_by(reservation_code: e['reservation_code'])
         
              if @reserva != nil
                @reserva.status = e['status']
                @reserva.save
              end
            end 
          }
          if i >= 0
            @response = wired.mark_bookings(reservations)
            # @response['response'] = reservations
          end 
      end
      format.json { render :json => @response}
    end
  end

  # DELETE /reservas/1
  # DELETE /reservas/1.json
  def destroy
    @reserva.destroy
    respond_to do |format|
      format.html { redirect_to reservas_url, notice: 'Reserva was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_reserva
      @reserva = Reserva.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    # def reservations_params
    #     # params.permit(reservations:[])
    #     #params.require(:reserva).permit(:id_channel, :special_offer, :reservation_code, :arrival_hour, :booked_rate, :rooms, :customer_mail, :customer_country, :children, :payment_gateway_fee, :customer_surname, :date_departure, :forced_price, :amount_reason, :customer_city, :opportunities, :date_received, :was_modified, :sessionSeed, :customer_name, :date_arrival, :status, :channel_reservation_code, :customer_phone, :orig_amount, :men, :customer_notes, :customer_address, :status_reason, :roomnight, :customer_language, :fount, :customer_zip, :amount, :cc_info, :room_opportunities, :customer_language_iso)
    # end
end
