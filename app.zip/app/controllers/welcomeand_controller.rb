class WelcomeController < ApplicationController
    require 'wired'
    require 'date'
    def index
        wired = Wired.new
        wired.aquire_token

     #$token = wired.aquire_token
     
     # @response=wired.fetch_rooms()

    # Update room values
    # ==== Attributes
    # * +dfrom+ - A Ruby date object (start date)
    # * +rooms+ - A hash with the following structure: [{'id' => room_id, 'days' => [{'avail' => 0}, {'avail' => 1}]}]
        dfrom = Date.new(2016,2,9)
    
        dto = Date.new(2016,2,10)
        


    # LEE ARCHIVO TXT
    # fd = IO.sysopen('c:\canalesdeventa\prueba.txt')
    # liner=""
    # File.open('prueba.txt', 'r') do |f1|  
    #   while line = f1.gets  
    #     liner=liner+'\n '+line
    #   end
    # end
    # @rooms_ar = liner

    # ACTUALIZA DISPONIBILIDAD
    # rooms=[{'id' => 113348,'days' => Array.new(14) { Hash.new }},{'id' => 113301, 'days' => Array.new(14) { Hash.new }}]
    # rooms[1]['days'][3]['no_ota']=1
    # rooms=[{'id' => 113301, 'days' => Array.new(1) { Hash.new }}]
    # rooms[0]['days'][0]['avail']=3
    # @response=wired.update_avail(dfrom, rooms)

    # #CONSULTA ROOM
    #     rooms = [113301]
    #     @response = wired.fetch_rooms_value(dfrom, dto, rooms)

    #CREA NUEVA RESERVA
    # rooms = {'113301' => [1, 'bb']}
    # customer = {'lname' => "Montes", 'fname' => "Paula", 'email' => "marcelomst1@gmail.com", 'city' => "Artigas", 'phone' => "+59891359488", 
    #             'street' => "Argentina 1234", 'country' => "UY", 'arrival_hour' => "10", 'notes' => "Prueba Artigas"}
    # amount = 57
    # @response = wired.new_reservation( lcode, dfrom, dto, rooms, customer, amount)
   
    # CANCELA RESERVA
    #rcode=1442067557
    #@cr=wired.cancel_reservation(lcode, rcode)

    # RECUPERA RESERVAS NUEVAS 
    ancillary= 1
    mark= 0
    @response=wired.fetch_new_bookings(ancillary, mark)
    # @response={'status' => response_a['status'],'response' => Array.new(response_a['response'].length) { Hash.new }}
    # i = 0
    # response_a['response'].each { |e| 

    #      @response['response'][i] = {
    #             'id_channel' => e['id_channel'],
    #             'reservation_code' => e['reservation_code'],
    #             'arrival_hour'  => e['arrival_hour'],
    #             'customer_mail'  => e['customer_mail'],
    #             'customer_country'  => e['customer_country'],
    #             'customer_surname'  => e['customer_surname'],
    #             'rooms_occupancies'  => e['rooms_occupancies'],
    #             'dayprices' => e['dayprices'],
    #             'date_departure'  => e['date_departure'],
    #             'customer_city'  => e['customer_city'],
    #             'customer_name'  => e['customer_name'],
    #             'date_arrival'  => e['date_arrival'],
    #             'customer_phone'   => e['customer_phone'],
    #             'customer_notes'  => e['customer_notes'],
    #             'customer_address'  => e['customer_address'],
    #             'amount'  => e['amount'],
    #             'status' => e['status']}
    #      i = i + 1
    # } 

    # rooms = [{'id_room' => 113348, 'incremento' => 1},{'id_room' => 113301, 'incremento' => -1}]
    # rooms_a = [113348,113301]
    # rooms_a= Array.new(rooms.length)
    # n = 0
    #   rooms.each { |e| 
    #        rooms_a[n] = e['id_room']
    #        n = n + 1
    #     }
    # @response = wired.fetch_rooms_value(dfrom, dto, rooms_a) 
    
    # # @response = @response_a['response']['113348']
    # # @response = Array.new(@response_a['response'].length) {'days' => Array.new( @response_a['response']['"#{rooms[0]['id_room']}"'}].length) { Hash.new }}
    # # @response = Array.new(@response_a['response'].length) {'days' => Array.new( @response_a['response']['113348'].length) { Hash.new }}
    # # @response = Array.new(@response_a['response'].length)
    # @response = Array.new(rooms.length) {Hash.new}
    # n = 0
    # ocur = (dto - dfrom + 1).to_i
    # @response.each { |e|  
    #     e['id'] = 0
    #     e['days'] = Array.new(ocur) {Hash.new}
    #     e['days'].each { |f| 
    #        f['avail'] =0
    #     }
    #     n=n+1
    # }
   
    # m = 0
    # rooms.each { |e| 
    #     n = 0
    #     stid_room=e['id_room'].to_s
    #     @response[m]['id']=e['id_room']
    #     @response_a['response'][stid_room].each { |f|  
    #         @response[m]['days'][n]['avail']=f['avail']+e['incremento']
    #         n = n + 1
    #     }
       
    #     m = m + 1
    #  }
    end
end
	