class Geoname < ActiveRecord::Base
end
