class Room < ActiveRecord::Base
	belongs_to :reserva
end
