module GeonamesHelper
end
