class WelcomeController < ApplicationController
    require 'wired'
    require 'date'
    def index
        wired = Wired.new
        wired.aquire_token
         ancillary= 1
         mark= 0
        @response = wired.fetch_new_bookings(ancillary, mark)
        # rcode=  1457617240  
        # @response=wired.fetch_booking(rcode)
        # @response['response'].each { |e|
          
        #   }
        # dfrom = Date.new(2016,3,4)
        # dto = Date.new(2016,3,5)

        # rooms_a = [113348]
    
        # @response = wired.fetch_rooms_value(dfrom, dto, rooms_a) 


        # dhoy = Date.today - 1
        # # @response =  dhoy
        # if @response['status'] = -101 and dfrom == dhoy
        #     if dto > dfrom
        #         dfrom = dfrom + 1
        #         @response = wired.fetch_rooms_value(dfrom, dto, rooms_a)
        #         @response['response_1'] = 'Fecha correjida'
        #     else
        #         @response['status']=0
        #         @response['response']='Determinado por PMS'
        #     end
        # end    
    
    end 
  #   def dto
  #       @cant=@cant+1
  #       arDto= @dto.split('/').collect! {|n| n.to_i}
  #       dto=Date.new(arDto[2],arDto[1],arDto[0])
  #       dto = dto + 1
  #   end
 end
	