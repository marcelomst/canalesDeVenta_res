class Solicitud < ActiveRecord::Base
end
